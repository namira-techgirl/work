<?php
	//session_start();
	//Connection Established
	//$con=mysqli_connect("localhost","root") or die("Server Not Connected");	
	//Connect Database
	//$db=mysqli_select_db($con,"gpgdb") or die("Database Not Found");
	$con=mysqli_connect("207.246.242.117","919009_gpgdb","Namira@123") or die("Server Not Found");
$db=mysqli_select_db($con,"919009_gpgdb") or die("Databse not Found"); 

	session_start();
?>
<?php
	//ADMIN
	if(isset($_REQUEST["sub"]))
		{
			$t1=$_REQUEST["val1"];
			$t2=$_REQUEST["val2"];
		
			$q1="select * from admin where uname='$t1' and pwd='$t2'";
			
			$res1=mysqli_query($con,$q1);
		
			$m1=mysqli_num_rows($res1);
		
			if($m1>0)
			{
				 $_SESSION["uname"] = $t1;
				header ("Location: ../admin/main.php");
			}
			else
			{
		
				$q2="select * from jobseeker where email='$t1' and password='$t2'";

				$res2=mysqli_query($con,$q2);

				$m2=mysqli_num_rows($res2);
				
				if($m2>0)
				{
				    $_SESSION["email"] = $t1;
						
					header ("Location: ../jobseeker/main.php");
				}
				else
				{					
					$msg="Invalid Email or Password";
				}
			}
		}
?>
<?php
	//HOD
	if(isset($_REQUEST["sub"]))
	{
		$t1=$_REQUEST["val1"];
		$t2=$_REQUEST["val2"];
		
		$q="select * from hod where hemail='$t1' and hpwd='$t2'";
		
		$res=mysql_query($q,$con);
		
		$m=mysql_num_rows($res);
		
		if($m>0)
		{
			$s=mysql_fetch_array($res);
			extract($s);
			
			$_SESSION["hid"] = $s[0];
			$_SESSION["hname"] = $s[1];
			$_SESSION["hemail"]=$s[2];
			$_SESSION["depid"]=$s[6];
			header ("Location: ../hod/main.php");
			
		}
		else
		{
			$msg="Invalid Email or Password";
		}
	}
?>
<?php
	//Student Alumni
	if(isset($_REQUEST["sub"]))
	{
		$t1=$_REQUEST["val1"];
		$t2=$_REQUEST["val2"];
		$t3 = "Alumni";
		$t4 = "Active";
		$q="select * from student where stu_email='$t1' and stu_pwd='$t2' and type='$t3' and status='$t4'";
		
		$res=mysql_query($q,$con);
		
		$m=mysql_num_rows($res);
		
		if($m>0)
		{
			$s=mysql_fetch_array($res);
			extract($s);
			
			$_SESSION["stuid"] = $s[0];
			$_SESSION["stu_fname"] = $s[1];
			$_SESSION["stu_lname"] = $s[2];
			$_SESSION["stu_email"] = $s[3];
			$_SESSION["stu_pwd"] = $s[4];
			$_SESSION["hid"] = $s[11];
			$_SESSION["stype"] = $s[12];
			$_SESSION["status"] = $s[13];
			header ("Location:../senior.php");
		}
		else
		{
			$msg="Invalid Email or Password";
		}
	}
	//Student Junior
	if(isset($_REQUEST["sub"]))
	{
		$t1=$_REQUEST["val1"];
		$t2=$_REQUEST["val2"];
		$t3 = "Junior";
		$t4 = "Active";
		$q="select * from student where stu_email='$t1' and stu_pwd='$t2' and type='$t3' and status='$t4'";
		
		$res=mysql_query($q,$con);
		
		$m=mysql_num_rows($res);
		
		if($m>0)
		{
			$s=mysql_fetch_array($res);
			extract($s);
			
			$_SESSION["stuid"] = $s[0];
			$_SESSION["stu_fname"] = $s[1];
			$_SESSION["stu_lname"] = $s[2];
			$_SESSION["stu_email"] = $s[3];
			$_SESSION["stu_pwd"] = $s[4];
			$_SESSION["hid"] = $s[11];
			$_SESSION["stype"] = $s[12];
			$_SESSION["status"] = $s[13];
			header ("Location:../junior.php");
		}
		else
		{
			$msg="Invalid Email or Password";
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V15</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form-title" style="background-image: url(images/bg-01.jpg);">
					<span class="login100-form-title-1">
						Sign In
					</span>
				</div>

				<form class="login100-form validate-form">
					<div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">Username</span>
						<input class="input100" type="text" name="val1" placeholder="Enter username">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="val2" placeholder="Enter password">
						<span class="focus-input100"></span>
					</div>
					<div class="container-login100-form-btn">
						<input type="submit" class="login100-form-btn" name="sub" value="Login" />
						<a href="../Registration/RegForm.php" class="login100-form-btn">Registration</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
<?php
	//session_start();
	$con=mysqli_connect("localhost","root","") or die("Server Not Found");
	if($con)
	{
		$db=mysqli_select_db($con,"gpgdb") or die("Databse not Found");
		if($db)
		{	
			//echo "DB Connect";
		}
	}
?>

<?php
if(isset($_SESSION["uname"]))
{
	$v=$_SESSION["uname"];
}
if(isset($_REQUEST["sub"]))
{
	$t1=$_REQUEST["npwd"];
	
	$q="update admin set pwd='$t1' where  uname='$v'";
	
	$ex=mysqli_query($con,$q);
	
	if($ex>0)
	{
		header("Location:../Login/index.php");
	}
}
?>
<form action="#" method="post">
<table class="table">
<tr>
<td>New Password</td>
<td><input type="password" name="npwd" class="form-control"></td>
</tr>
<tr>
<td><input type="submit" class="btn btn-info" name="sub" value="Change Password"></td>
</tr>
	
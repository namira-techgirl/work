<ul class="nav">
				<!--<li> 
 
                    <a href="?id=addstate">
                        <i class="pe-7s-graph"></i>
                        <p>STATE</p>
                    </a>
                </li>
				
				<li>
                    <a href="?id=addcity">
                         <i class="pe-7s-graph"></i>
                        <p>City</p>
                    </a>
                </li>-->
				<li>
                    <a href="?id=jobpost">
                         <i class="pe-7s-graph"></i>
                        <p>Manage Job Post</p>
                    </a>
                </li>
				<li>
                    <a href="?id=changepwd">
                         <i class="pe-7s-graph"></i>
                        <p>Change Password</p>
                    </a>
                </li>

</ul>

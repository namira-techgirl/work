<?php
$con=mysqli_connect("localhost","root","") or die("Server Not Found");
	if($con)
	{
		$db=mysqli_select_db($con,"gpgdb") or die("Databse not Found");
		if($db)
		{	
			//echo "DB Connect";
		}
	}
?>
<h2>Job Post</h2>
<table class="table table-striped">
<tr>
	<th>Designation</th>
	<th>Applicant Name</th>
	<th>Study</th>
	<th>Experience</th>
	<th>Resume</th>
	<th>Email</th>
</tr>

<?php

//$q="select * from city";
$q="select c.cname,j1.fname,j1.lname,j.study,j.experience,j.resume,j.brief from category c inner join jobpost j on c.cid=j.Id inner join jobseeker j1 on j.Jid = j1.Jid";


$res=mysqli_query($con,$q);

$nrow = mysqli_num_rows($res);


if(isset($nrow))
{
while($row=mysqli_fetch_array($res))
{
?>
<tr>
<td><?php echo $row[0];?></td>
<td><?php echo $row[1]." ".$row[2];?></td>
<td><?php echo $row[3]; ?></td>
<td><?php echo $row[4]; ?></td>
<td>
<a href="../resume/<?php echo $row[5]; ?>" target="_blank" >Show</a>
</td>
<td>
<a href="emailsent.php">Email</a>
</td>
</tr>
<?php
}
}
?>


</form>	
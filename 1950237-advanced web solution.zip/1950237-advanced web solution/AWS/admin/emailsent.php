<?php

	include("connection.php");
	$con=mysqli_connect("localhost","root","") or die("Server Not Found");
	if($con)
	{
		$db=mysqli_select_db($con,"gpgdb") or die("Databse not Found");
		if($db)
		{	
			//echo "DB Connect";
		}
	}

	$t1="gaurang";
	$t6="chauhan";
	$t2="gaurang@gmail.com";
	$t3="vadodara";
	$t4="390015";
	$t5="9723636072";
			
	$mailbody = "<table width='560' border=0 align='left' cellpadding='5' cellspacing='0' style='border:solid 5px #d2552c;'><tr><td height='33' colspan='4'  style='background-color:#d2552c;'><div align='center'>
                <font color='#333366' size='3'><strong> </strong></font><font color='#333366' size='3'><strong>Demo Account Form</strong></font></div></td></tr><tr><td valign=top width='120'>
                <b> First Name</b> </td><td valign=top width='5' align='center'><div align='center'><b>:</b></div></td>
                <td valign='top'>$t1</td></tr><tr><td valign=top width='120'>
                <b> Last Name</b> </td><td valign=top width='5' align='center'><div align='center'><b>:</b></div></td>
                <td valign='top'>$t6</td></tr><tr><td valign=top><strong>Contact Person</strong> </td><td valign=top>
                <div align='center'><b> :</b></div></td><td valign='top'>$t5</td></tr><tr><td VALIGN=TOP><b>Email</b></td>
                <td VALIGN=TOP><div align='center'><b>:</b></div></td><td valign='top'>$t2</td></tr><tr></tr><tr><td VALIGN=TOP><b>Zip Code</b></td><td VALIGN=TOP>
                <div align='center'><b>:</b></div></td><td valign='top'>$t4</td></tr><tr><td VALIGN=TOP><b>Address</b> </td>
                <td VALIGN=TOP><div align='center'><b>:</b></div></td><td valign='top'>$t3</td></tr><tr><td colspan=4>&nbsp;</td></tr>
                </table>";
				
	//-- do not forget to change the email address here
	$to = 'gaurang.chauhan02@gmail.com';   //change email addess as per the domain name and its contact email address
	
	// $to = 'arpitshah.2185@gmail.com';   //change email addess as per the domain name and its contact email address
	$cc='arpitshah.2185@gmail.com';
    
    $subject = 'Inquiry from Nyara Consultancy Services';

    $headers  = 'MIME-Version: 1.0' . "\r\n";
    
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    // Additional headers
    $headers .= 'From: '. $t2 ."\r\n";
    
	//echo"$mailbody";
	mail( $to, "Subject: $subject", $mailbody, $headers );
	echo "Email sent Successfully";
	//header ("Location:../admin/main.php");
?>
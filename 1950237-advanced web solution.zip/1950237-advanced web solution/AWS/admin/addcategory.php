<?php
	$con=mysqli_connect("localhost","root","") or die("Server Not Found");
	if($con)
	{
		$db=mysqli_select_db($con,"gpgdb") or die("Databse not Found");
		if($db)
		{	
			//echo "DB Connect";
		}
	}
?>
<?php

if(isset($_REQUEST["sub"]))
{
	$t1=$_REQUEST["cname"];
	
	$q="insert into category(cname) values('$t1')";
	
	$ex=mysqli_query($con,$q);
	
	if($ex>0)
	{
		$msg="Data Inserted";
	}
}

if(isset($_REQUEST["id2"]))
{
	$v=$_REQUEST["id2"];
	
	$q="delete from category where cid=$v";
	
	$ex=mysqli_query($con,$q);
	
	if($ex>0)
	{
		header("Location:main.php?id=addcategory");
	}
}


?>
<h2>Department</h2>
<?php
if(isset($msg))
{
	echo"$msg";
}


?>
<form action="#" method="post">
<table class="table">
<tr>
	<td>Name</td>
	<td>
	<input type="text" name="cname" class="form-control" required />
	</td>
</tr>
<tr>
	<td><input type="submit" name="sub" class="btn btn-info" value="Add">
	</td>
</tr>
</table>
<h2>Show Department</h2>
<table class="table table-striped">
<tr>
	<th>Name</th>
	<th>Edit</th>
	<th>Delete</th>
</tr>
<?php
	
	include("connection.php");
	
	$q="select * from category";
	
	$res=mysqli_query($con,$q);
	
	while($row=mysqli_fetch_array($res))
	{
	?>
		<tr>
		<td><?php echo $row[1];?></td>
		
		<td><a href="?id=updatecategory&id1=<?php echo $row[0];?>">Edit</a></td>
		<td><a href="addcategory.php?id2=<?php  echo $row[0];?>" onClick="return confirm('sure u want to delete?')">Delete</a></td>
		</tr>
	<?php
}
?>
</table>

</form>


<?php
	//include("connection.php");	
	$con=mysqli_connect("localhost","root","") or die("Server Not Found");
	if($con)
	{
		$db=mysqli_select_db($con,"gpgdb") or die("Databse not Found");
		if($db)
		{	
			//echo "DB Connect";
		}
	}
?>
<?Php
		//Check Duplicate EmailID
		if(isset($_REQUEST["sub"]))
		{
			$t1=$_REQUEST["v3"];
		
			$q1="select * from jobseeker where email='$t1'";
            echo $q1;		
			
			$res1=mysqli_query($con,$q1);
			if(isset($res))
			{
				$m1=mysqli_num_rows($res1);		
				if($m1>0)
				{
					$msg = "Email ID Already Used!!!!";
				}
				else
				{
					
					//Insert Student Record
					if(isset($_REQUEST["sub"]))
					{
						$t1=$_REQUEST["v1"];
						$t2=$_REQUEST["v2"];
						$t3=$_REQUEST["v3"];
						$t4=$_REQUEST["v4"];
						$t5=$_REQUEST["v5"];
					
						$q="insert into jobseeker(fname,lname,email,contact,password) values ('$t1','$t2','$t3','$t4','$t5')";
						echo $q;
						
						$ex=mysqli_query($con,$q);
						echo "The value is ".$ex;
						if($ex>0)
						{
							header ("Location: ../Login/index.php");		
						}
						else
						{
							$msg="Not Inserted";
						}
					}
				}
			}
			else
			{
				if(isset($_REQUEST["sub"]))
					{
						$t1=$_REQUEST["v1"];
						$t2=$_REQUEST["v2"];
						$t3=$_REQUEST["v3"];
						$t4=$_REQUEST["v4"];
						$t5=$_REQUEST["v5"];
					
						$q="insert into jobseeker(fname,lname,email,contact,password) values ('$t1','$t2','$t3','$t4','$t5')";
						echo $q;
						
						$ex=mysqli_query($con,$q);
						
						echo "<br/>The value is ".$ex;
						if($ex>0)
						{
							header ("Location: ../Login/index.php");		
						}
						else
						{
							$msg="Not Inserted";
						}
					}			
			}			
		}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Registration Form</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>
<body>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading">
                    <h2 class="title">Sign-Up Form</h2>
                </div>
                <div class="card-body">
					<h2 align="center">
						<?php
							if(isset($msg))
							{
								echo $msg;
							}
						?>
					</h2>
                    <form action="#" method="POST">
						<div class="form-row m-b-55">
							<a href="../index.php" class="btn btn-primary" style="color:#FF0000;">Home</a>
						</div>
                        <div class="form-row m-b-55">
							
                            <div class="name">Name</div>
                            <div class="value">
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="v1" required />
                                            <label class="label--desc">first name</label>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group-desc">
                                            <input class="input--style-5" type="text" name="v2"required />
                                            <label class="label--desc">last name</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="name">Email</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="email" name="v3" required />
                                </div>
                            </div>
                        </div>
						 <div class="form-row">
                            <div class="name">Contact</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="text" name="v4" required />
                                </div>
                            </div>
                        </div>                        
						<div class="form-row">
                            <div class="name">Password</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-5" type="password" name="v5" required />
                                </div>
                            </div>
                        </div>
                        <div>
							<input type="submit" class="btn btn--radius-2 btn--red" name="sub" value="Register" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->
<!-- ==============================================
//  Created by PHP Dev Zone           			 ||
//	http://php-dev-zone.blogspot.com             ||
//  Contact for any Web Development Stuff        ||
//  Email: ketan32.patel@gmail.com     			 ||
//=============================================-->
<?php 
	$state=intval($_GET['state']);
	$city=intval($_GET['city']);
	$con = mysqli_connect('localhost','root', ''); 
	if (!$con) {
		die('Could not connect: ' . mysql_error());
	}
	mysqli_select_db($con,'gpgdb');
	$query="SELECT * FROM area WHERE sid=$state and cityid=$city";// order by cityname";
	//echo $query;
	$result=mysqli_query($query);
	//echo $result;
?>
	<select name="area" class="form-control">
	<option disabled="disabled" selected="selected">Choose option</option>
<?php 
	while ($row=mysqli_fetch_array($result)) 
	{ 
		?>
			<option value=<?php echo $row['arid']?>>
			<?php echo $row['arname']?>
		
			</option>
		<?php 
	} 
?>
</select>
<?php 
	$state=intval($_GET['state']);
	$con = mysqli_connect('localhost','root', ''); 
	if (!$con) {
		die('Could not connect: ' . mysql_error());
	}
	mysqli_select_db($con,'gpgdb');
	$query="SELECT * FROM city WHERE sid=$state";// order by cityname";
	//echo $query;
	$result=mysqli_query($query);
	//echo $result;
?>
	<select name="city" class="form-control" onchange="getArea(<?php echo $state?>,this.value)">
	<option disabled="disabled" selected="selected">Choose option</option>
<?php 
	while ($row=mysqli_fetch_array($result)) 
	{ 
		?>
			<option value=<?php echo $row['cityid']?>>
			<?php echo $row['cityname']?>
		
			</option>
		<?php 
	} 
?>
</select>
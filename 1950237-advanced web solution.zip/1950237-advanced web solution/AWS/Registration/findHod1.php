<?php 
	$department=intval($_GET['department']);
	$con = mysqli_connect('localhost','root', ''); 
	if (!$con) {
		die('Could not connect: ' . mysql_error());
	}
	mysqli_select_db($con,'gpgdb');
	$query="SELECT * FROM hod WHERE cid=$department";// order by cityname";
	//echo $query;
	$result=mysqli_query($query);
	//echo $result;
?>
	<select name="hod" class="form-control">
	<option disabled="disabled" selected="selected">Choose option</option>
<?php 
	while ($row=mysqli_fetch_array($result)) 
	{ 
		?>
			<option value=<?php echo $row['hid']?>>
			<?php echo $row['hname']?>
		
			</option>
		<?php 
	} 
?>
</select>
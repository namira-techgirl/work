<?php
 $con=mysqli_connect("localhost","root","") or die("Server Not Found");
	if($con)
	{
		$db=mysqli_select_db($con,"gpgdb") or die("Databse not Found");
		if($db)
		{	
			//echo "DB Connect";
		}
	}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>namira</title>

    <!-- Favicon -->
     <link rel="icon" href="banner/gpg.jpg">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- ##### Preloader ##### -->
    
    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <!-- Top Header Area -->
        <div class="top-header">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-12 h-100">
                        <div class="header-content h-100 d-flex align-items-center justify-content-between">
                            <div class="academy-logo">
                                <a href="index.php"><img src="banner/logo.PNG" alt="" style="height:90px;"></a>
                            </div>
                            <div class="login-content">
                                <a href="Login/index.php">Register / Login</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="academy-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="academyNav">

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
	                                <li><a href="aboutus.php">About Us</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>

                        <!-- Calling Info -->
                        <div class="calling-info">
                            <div class="call-center">
                                <a href="tel:+91 9723636072"><i class="icon-telephone-2"></i><span>9898789789</span></a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img" style="background-image: url(img/bg-img/breadcumb.jpg);">
        <div class="bradcumbContent">
            <h2>About Us</h2>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->

    <!-- ##### About Us Area Start ##### -->
    <section class="about-us-area mt-50 section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto wow fadeInUp" data-wow-delay="300ms">
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-12 wow fadeInUp" data-wow-delay="400ms">
                    <p align="justify">The company HappyTech is growing and advertises a significant number of positions. Therefore, the number of applications they have to deal with is increasing too. The company’s policy is to respond to both the successful and unsuccessful applications by sending them feedback. As writing up letters for every applicant takes a lot of time, the company identified an ontology that could be used by a software application to generate the feedback. The feedback application will be used by anybody involved in reviewing the applications.</p>
				</div>
            <div class="row">
                <div class="col-12">
                    <div class="about-slides owl-carousel mt-100 wow fadeInUp" data-wow-delay="600ms">
                       <!-- <img src="img/bg-img/bg-3.jpg" alt="">
                        <img src="img/bg-img/bg-2.jpg" alt="">
                        <img src="img/bg-img/bg-1.jpg" alt="">-->
						<img src="banner/1.jpg" alt="" style="height:500px;">
                        <img src="banner/2.jpg" alt="" style="height:500px;">
                        <img src="banner/4.jpg" alt="" style="height:500px;">
						
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### About Us Area End ##### -->

    <!-- ##### Team Area Start ##### -->
   <section class="teachers-area section-padding-0-100">
        <!--<div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center mx-auto wow fadeInUp" data-wow-delay="300ms">
                       <span>&nbsp;</span>
                        <h3>Head of Department</h3>
                    </div>
                </div>
            </div>

           <div class="row">-->
                <!-- Single Teachers -->
				<!--<?php
					$q = "select T1.hid, T1.hname, T2.cname, T1.hpath from hod T1, category T2 where T1.cid = T2.cid";
					$res = mysql_query($q,$con);

					while($row = mysql_fetch_array($res))
					{
						?>
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-teachers-area text-center mb-100 wow fadeInUp" data-wow-delay="400ms">-->
                        <!-- Thumbnail -->
                        <!--<div class="teachers-thumbnail">
                            <img src="admin/hodpic/<?php echo $row[3]; ?>" alt="">
                        </div>-->
                        <!-- Meta Info -->
                        <!--<div class="teachers-info mt-30">
						
									<tr>			
										<h5><?php echo $row[1]; ?></h5>
                            			<span><?php echo $row[2]; ?></span>
									</tr>  
                        </div>
                    </div>
                </div> 
             		<?php
				}
			?>  
            </div>

            <div class="row">
                <div class="col-12">
                    
                </div>
            </div>
        </div>-->
    </section> 
    <!-- ##### Features Area Start ##### -->

    <!-- ##### Footer Area Start ##### -->
 	<footer class="footer-area">
        <div class="bottom-footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>
<?php
	session_start();
	include("connection.php");
?>

<?php
if(isset($_SESSION["email"]))
{
	$v=$_SESSION["email"];
	
	$q="select * from jobseeker where email='$v'";
	
	$res=mysqli_query($con,$q);
	
	$row=mysqli_fetch_array($res);
	
	extract($row);
}

if(isset($_REQUEST["sub"]))

{
	$t1=$_REQUEST["fname"];
	
	$t2=$_REQUEST["lname"];
	
	$t3=$_REQUEST["email"];
	
	$t4=$_REQUEST["contact"];
	
	$q="update jobseeker set fname='$t1',lname='$t2',email='$t3',contact='$t4' where  email='$v'";
	
	$ex=mysqli_query($con,$q);
	
	if($ex>0)
	{
		header("Location:main.php");
	}
}
?>
<form action="#" method="post">
<table class="table">
<tr>
<td>First Name</td>
<td><input type="text" name="fname" class="form-control" value="<?php 
if(isset($row))
{
	echo $row[1];
}

?>"></td>
</tr>
<tr>
<td>Last Name</td>
<td><input type="text" name="lname" class="form-control" value="<?php 
if(isset($row))
{
	echo $row[2];
}

?>"></td>
</tr>

<tr>
<td>Email</td>
<td><input type="text" name="email" readonly="true" class="form-control" value="<?php 
if(isset($row))
{
	echo $row[3];
}

?>"></td>
</tr>

<tr>
<td>Contact</td>
<td><input type="text" name="contact" class="form-control" value="<?php 
if(isset($row))
{
	echo $row[4];
}

?>"></td>
</tr>




<tr>
<td><input type="submit" class="btn btn-info" name="sub" value="Update"></td>
</tr>
	
<?php

//$con=mysqli_connect("localhost","root","") or die("Server Not Found");
$con=mysqli_connect("207.246.242.117","919009_gpgdb","Namira@123") or die("Server Not Found");
$db=mysqli_select_db($con,"gpgdb") or die("Databse not Found"); 

?>
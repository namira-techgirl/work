<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php

echo "Previous Page".$_SERVER['HTTP_REFERER'];
	
?>
<html>
<head>
<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Happy Tech</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

</head>

<body>
<div class="wrapper"> 
  <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-5.jpg"> 
    <!--
        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag
    -->
    <div class="sidebar-wrapper"> 
      <div class="logo"> <a href="#" class="simple-text"> 
       Happy Tech</a> </div>
      <?php include("menu.php");?>
    </div>
  </div>
  <div class="main-panel"> 
    <?php include("header.php");?>
    <div class="content"> 
      <div class="container-fluid"> 
       
        <div class="col-md-12"> 
          <div class="card"> 
          
            <div class="content text-justify"> 
              <?php
								if(isset($_REQUEST["id"]))
								{
								$v=$_REQUEST["id"];
								include("$v").".php";
								}
								else
								{
			 ?>
             <p style="line-height:28px;">
			 	In today’s competitive world, effective communication as well as the exchange of information is the key to success. As the university continues to grow larger and larger and by the time the number of students getting passed also increases, it is possible that they may not be in contact with each other.
This project focuses on developing a web service application using PHP that provides the space where alumni and students can come together and can be in touch with each other.

<p style="line-height:28px;"> This web application is more likely a social networking website which helps the students in their academic activities. Alumni can upload and share their pictures and other information on the web application. Only the authorized juniors can view and check the details. Alumni can also send message query to the current college student about job and carrier which they have designed and juniors can use it for their reference. Also juniors can send the query to the alumni regarding any subject or other information. And juniors and Alumni manage by HOD department wise. </p>

<p style="line-height:28px;">This system can be used as an application for the Alumni Information Database to manage the college information and student’s information. The system is an online application that can be accessed throughout the organization with proper login provided, which will give better service to the students.
</p>
<p style="line-height:28px;">
With the help of this web application student can send query, get mentoring and view the job vacancy. This web application provides effective bonding between both alumni and students. 


</p>
			 </p>
              <?php
								}
								 ?>
            </div>
          </div>
        </div>
        <div class="content"> 
          <div class="table-full-width"> 
            <table class="table">
            </table>
          </div>
          <div class="footer"> 
            <hr>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php include("footer.php");?></div>
</div> 
</body>
<!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>
</html>

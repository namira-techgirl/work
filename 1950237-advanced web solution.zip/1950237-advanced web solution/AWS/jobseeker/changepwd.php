<?php
	session_start();
	include("connection.php");
?>

<?php
if(isset($_SESSION["email"]))
{
	$v=$_SESSION["email"];
	
}

if(isset($_REQUEST["sub"]))
{
	$t1=$_REQUEST["npwd"];
	
	$q="update jobseeker set password='$t1' where  email='$v'";
	
	$ex=mysqli_query($con,$q);
	
	if($ex>0)
	{
		header("Location:../Login/index.php");
	}
}
?>
<form action="#" method="post">
<table class="table">
<tr>
<td>New Password</td>
<td><input type="password" name="npwd" class="form-control"></td>
</tr>



<tr>
<td><input type="submit" class="btn btn-info" name="sub" value="Update"></td>
</tr>
	
<ul class="nav">
				<li> 
 
                    <a href="?id=updateprofile">
                        <i class="pe-7s-graph"></i>
                        <p>Profile</p>
                    </a>
                </li>				
				<li>
                    <a href="?id=changepwd">
                         <i class="pe-7s-graph"></i>
                        <p>Change Password</p>
                    </a>
                </li>

           </ul>
